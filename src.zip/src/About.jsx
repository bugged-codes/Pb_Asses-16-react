import React from 'react'

const About = () => {
  return (
    <div>
      <h1>Student</h1>
      <p style={{color:"white"}}>
        1.Ideal student traits make him unique, among others.<br />
        2.It is believed that an ideal student will never waste his time and energy on non-productive things.<br />
        3.The ideal student has inborn winning qualities.
        4.Ideal students will always goal-oriented. Thus, they play according to actions to reach their goals.<br />
        5.It is proven that ideal students will punctual in school and always on time regularly.<br />
        6.He respects everyone. He also obeys their instructions and orders.<br />
        7.Ideal students are not bookworms. They keenly observe and read wisely.<br />
        8.Ideal students take his studies with all seriousness. They don’t allow any other activities to disturb them.<br />
        9.Ideal students always seek the teacher’s guidance. Also, they believe in the knowledge of their teachers.<br />
        10.Ideal students are always well-behaved and disciplined. They never try to break the rules of schools, colleges, or parents.<br />
      </p>
    </div>
  )
}

export default About